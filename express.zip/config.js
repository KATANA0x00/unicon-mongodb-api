const config = {
    uri: "mongodb+srv://uniconfinder:1WmYjjDYspgo7cAu@unicons-cluster.1bygmgq.mongodb.net/?retryWrites=true&w=majority&appName=unicons-cluster",
    databaseName: 'Unicon',
    infoCollection: 'unicon_info',
    positionCollection: 'unicon_positions',
    port: 3000
};

module.exports = config;